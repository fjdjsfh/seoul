package com.example.demo.controller;

import com.example.demo.entity.SeoulCommercial;
import com.example.demo.entity.SeoulPopulation;
import com.example.demo.service.SeoulCommercialService;
import com.example.demo.service.SeoulPopulationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seoul")
public class SeoulDataController {

    private final SeoulCommercialService commercialService;
    private final SeoulPopulationService populationService;

    public SeoulDataController(SeoulCommercialService commercialService, SeoulPopulationService populationService) {
        this.commercialService = commercialService;
        this.populationService = populationService;
    }

    @GetMapping("/commercial/{districtCode}")
    public ResponseEntity<List<SeoulCommercial>> getCommercialData(@PathVariable String districtCode) {
        List<SeoulCommercial> data = commercialService.getCommercialDataByDistrict(districtCode);
        return ResponseEntity.ok(data);
    }

    @GetMapping("/population/{districtCode}")
    public ResponseEntity<SeoulPopulation> getPopulationData(@PathVariable String districtCode) {
        SeoulPopulation data = (SeoulPopulation) populationService.getPopulationByDistrict(districtCode);
        return ResponseEntity.ok(data);
    }
}
