package com.example.demo.repository;

import com.example.demo.entity.SeoulCommercial;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SeoulCommercialRepository extends JpaRepository<SeoulCommercial, Long> {

    SeoulCommercial findByDistrictCodeAndBusinessTypeAndDate(String districtCode, String businessType, String date);

	List<SeoulCommercial> findByDistrictCode(String districtCode);
}
